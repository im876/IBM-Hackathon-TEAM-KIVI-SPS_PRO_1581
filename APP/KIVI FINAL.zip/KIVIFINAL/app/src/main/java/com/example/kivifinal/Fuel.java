package com.example.kivifinal;

import com.ibm.watson.developer_cloud.http.RequestBuilder;

public class Fuel {
    public static RequestBuilder get(String s) {
    }
}
