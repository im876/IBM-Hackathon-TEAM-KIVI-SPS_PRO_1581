package com.example.kivifinal;

public interface FuelError {
}
